#include "LSM6DSO.h"
#include "nrf_delay.h"
#include <nrfx_gpiote.h>
#include "uart.h"

struct SensorSettings settings;
//****************************************************************************//
//
//  Configuration section
//
//  This uses the stored SensorSettings to start the IMU
//  Use statements such as "myIMU.settings.commInterface = SPI_MODE;" or
//  "myIMU.settings.accelEnabled = 1;" to configure before calling init_lsm6dso();
//
//****************************************************************************//
lsm6dso_status_t init_lsm6dso(void){

    // uart_puts("\r\nThis is LSM6DSO init start!!\r\n");

    // ------- SPI configuration --------------
    nrfx_spi_config_t spi_config;
    spi_config.ss_pin =        LSM6DSO_SPI_SS_PIN;
    spi_config.miso_pin =      LSM6DSO_SPI_MISO_PIN;
    spi_config.mosi_pin =      LSM6DSO_SPI_MOSI_PIN;
    spi_config.sck_pin =       LSM6DSO_SPI_SCK_PIN;
    spi_config.irq_priority =  NRFX_SPI_DEFAULT_CONFIG_IRQ_PRIORITY,
    spi_config.orc =           0xFF,
    spi_config.frequency =     NRF_SPI_FREQ_1M;
    spi_config.mode =          NRF_SPI_MODE_3;
    spi_config.bit_order =     NRF_SPI_BIT_ORDER_MSB_FIRST;
    spi_config.skip_psel_cfg = false;
    spi_config.skip_gpio_cfg = false;
    nrfx_err_t err_code = nrfx_spi_init(&m_spi_lsm6dso, &spi_config, NULL, NULL);

    nrf_delay_ms(10);
    //------------- LSM6DSO Test -------------
    uint8_t readCheck;
    read_register_lsm6dso(&readCheck, LSM6DSO_WHO_AM_I);
    if ( readCheck != LSM6DSO_ID ) {
        // uart_puts("\r\n LSM6DSO Test Error!!\r\n");
        decimal_to_char(readCheck);
    }
    else {
        // uart_puts("\r\n LSM6DSO Test Succuss!!");
        // uart_puts("\r\n");
        // uart_puts("\r\n LSM6DSO's WHO_AM_I --> ");
        // decimal_to_char(readCheck);
	    // uart_puts("\r\n");
    }

    settings.gyroEnabled =        1;    //Can be 0 or 1
    settings.gyroRange =          2000; //Max deg/s.  Can be: 125, 245, 500, 1000, 2000
    settings.gyroSampleRate =     416;  //Hz.  Can be: 13, 26, 52, 104, 208, 416, 833, 1666
    settings.gyroBandWidth =      400;  //Hz.  Can be: 50, 100, 200, 400;
    settings.gyroFifoEnabled =    1;    //Set to include gyro in FIFO
    settings.gyroFifoDecimation = 1;    //set 1 for on /1

    settings.accelEnabled =        1;
    settings.accelODROff =         1;
    settings.accelRange =          16;  //Max G force readable.  Can be: 2, 4, 8, 16
    settings.accelSampleRate =     416; //Hz.  Can be: 13, 26, 52, 104, 208, 416, 833, 1666, 3332, 6664, 13330
    settings.accelBandWidth =      100; //Hz.  Can be: 50, 100, 200, 400;
    settings.accelFifoEnabled =    1;   //Set to include accelerometer in the FIFO
    settings.accelFifoDecimation = 1;   //set 1 for on /1

    settings.tempEnabled = 1;

    //Select interface mode
    settings.commMode = 1;  //Can be modes 1, 2 or 3

    //FIFO control data
    settings.fifoThreshold = 3000;  //Can be 0 to 4096 (16 bit bytes)
    settings.fifoSampleRate = 10;   //default 10Hz
    settings.fifoModeWord = 0;      //Default off

    //Setup the acceleration**********************************************
    uint8_t dataToWrite = 0; //Start Fresh!
    if (settings.accelEnabled == 1) {
        //Build config reg
        //First patch in filter bandwidth
        switch (settings.accelBandWidth) {
            case 50:  dataToWrite |= LSM6DSO_BW_XL_50Hz;  break;
            case 100: dataToWrite |= LSM6DSO_BW_XL_100Hz; break;
            case 200: dataToWrite |= LSM6DSO_BW_XL_200Hz; break;
            case 400: dataToWrite |= LSM6DSO_BW_XL_400Hz; break;
            default:  //set default case to max passthrough
        }
        //Next, patch in full scale
        switch (settings.accelRange) {
            case 2:  dataToWrite |= LSM6DSO_FS_XL_2g;  break;
            case 4:  dataToWrite |= LSM6DSO_FS_XL_4g;  break;
            case 8:  dataToWrite |= LSM6DSO_FS_XL_8g;  break;
            case 16: dataToWrite |= LSM6DSO_FS_XL_16g; break;
            default:  //set default case to 16(max)
        }
        //Lastly, patch in accelerometer ODR
        switch (settings.accelSampleRate) {
            case 13:    dataToWrite |= LSM6DSO_ODR_XL_13Hz;    break;
            case 26:    dataToWrite |= LSM6DSO_ODR_XL_26Hz;    break;
            case 52:    dataToWrite |= LSM6DSO_ODR_XL_52Hz;    break;
            case 104:   dataToWrite |= LSM6DSO_ODR_XL_104Hz;   break;
            case 208:   dataToWrite |= LSM6DSO_ODR_XL_208Hz;   break;
            case 416:   dataToWrite |= LSM6DSO_ODR_XL_416Hz;   break;
            case 833:   dataToWrite |= LSM6DSO_ODR_XL_833Hz;   break;
            case 1660:  dataToWrite |= LSM6DSO_ODR_XL_1660Hz;  break;
            case 3330:  dataToWrite |= LSM6DSO_ODR_XL_3330Hz;  break;
            case 6660:  dataToWrite |= LSM6DSO_ODR_XL_6660Hz;  break;
            case 13330: dataToWrite |= LSM6DSO_ODR_XL_13330Hz; break;
            default:  //Set default to 104
        }
    } else {
        //dataToWrite already = 0 (powerdown);
    }
    //Now, write the patched together data
    write_register_lsm6dso(LSM6DSO_CTRL1_XL, dataToWrite);

    //Setup the ODR bit**********************************************
    read_register_lsm6dso(&dataToWrite, LSM6DSO_CTRL4_C);
    dataToWrite &= ~((uint8_t)LSM6DSO_BW_SCAL_ODR_ENABLED);
    if (settings.accelODROff == 1) {
        dataToWrite |= LSM6DSO_BW_SCAL_ODR_ENABLED;
    }
    write_register_lsm6dso(LSM6DSO_CTRL4_C, dataToWrite);

    //Setup the gyroscope**********************************************
    dataToWrite = 0; //Start Fresh!
    if (settings.gyroEnabled == 1) {
        //Build config reg
        //First, patch in full scale
        switch (settings.gyroRange) {
            case 125:  dataToWrite |= LSM6DSO_FS_125_ENABLED; break;
            case 245:  dataToWrite |= LSM6DSO_FS_G_245dps;    break;
            case 500:  dataToWrite |= LSM6DSO_FS_G_500dps;    break;
            case 1000: dataToWrite |= LSM6DSO_FS_G_1000dps;   break;
            case 2000: dataToWrite |= LSM6DSO_FS_G_2000dps;   break;
            default:  //Default to full 2000DPS range
        }
        //Lastly, patch in gyro ODR
        switch (settings.gyroSampleRate) {
            case 13:   dataToWrite |= LSM6DSO_ODR_G_13Hz;   break;
            case 26:   dataToWrite |= LSM6DSO_ODR_G_26Hz;   break;
            case 52:   dataToWrite |= LSM6DSO_ODR_G_52Hz;   break;
            case 104:  dataToWrite |= LSM6DSO_ODR_G_104Hz;  break;
            case 208:  dataToWrite |= LSM6DSO_ODR_G_208Hz;  break;
            case 416:  dataToWrite |= LSM6DSO_ODR_G_416Hz;  break;
            case 833:  dataToWrite |= LSM6DSO_ODR_G_833Hz;  break;
            case 1660: dataToWrite |= LSM6DSO_ODR_G_1660Hz; break;
            default:  //Set default to 104
        }
    } else {
        //dataToWrite already = 0 (powerdown);
    }
    //Write the byte
    write_register_lsm6dso(LSM6DSO_CTRL2_G, dataToWrite);

    //Setup the internal temperature sensor
    if (settings.tempEnabled == 1) {
        settings.tempSensitivity = 16;
    }
}

//****************************************************************************//
//
//  read_register_lsm6dsoRegion
//
//  Parameters:
//    *outputPointer -- Pass &variable (base address of) to save read data to
//    offset -- register to read
//    length -- number of bytes to read
//
//  Note:  Does not know if the target memory space is an array or not, or
//    if there is the array is big enough.  if the variable passed is only
//    two bytes long and 3 bytes are requested, this will over-write some
//    other memory!
//
//****************************************************************************//
lsm6dso_status_t read_register_region_lsm6dso(uint8_t* outputPointer, uint8_t offset, uint8_t length) {
    lsm6dso_status_t returnError = IMU_SUCCESS;
    uint8_t tmp_array[20] = {0};
    uint8_t tx_buf[2] = { offset | 0x80, 0x00 };
    nrfx_spi_xfer_desc_t spi_xfer_desc = NRFX_SPI_XFER_TRX(tx_buf, 2, tmp_array, length + 1);
    nrfx_err_t status = nrfx_spi_xfer(&m_spi_lsm6dso, &spi_xfer_desc, 0);
    //NRFX_ASSERT(status == NRFX_SUCCESS);
    for( uint8_t i = 0; i < length; i ++ ){
        *outputPointer = tmp_array[i+1];
        outputPointer ++;
    }
    return returnError;
}

//****************************************************************************//
//
//  read_register_lsm6dso
//
//  Parameters:
//    *outputPointer -- Pass &variable (address of) to save read data to
//    offset -- register to read
//
//****************************************************************************//
lsm6dso_status_t read_register_lsm6dso(uint8_t* outputPointer, uint8_t offset) {
    uint8_t result;
    lsm6dso_status_t returnError = IMU_SUCCESS;
    // ------------- SPI Process --------------
    uint8_t tx_buf[2] = { offset | 0x80, 0x00 };
    uint8_t rx_buf[2];
    nrfx_spi_xfer_desc_t spi_xfer_desc = NRFX_SPI_XFER_TRX(tx_buf, 2, rx_buf, 2);
    nrfx_err_t status = nrfx_spi_xfer(&m_spi_lsm6dso, &spi_xfer_desc, 0);
    result = rx_buf[1];
    //NRFX_ASSERT(status == NRFX_SUCCESS);
    if (result == 0xFF) {
        //we've recieved all ones, report
        returnError = IMU_ALL_ONES_WARNING;
    }
    *outputPointer = result;
    return returnError;
}

//****************************************************************************//
//
//  read_register_int16_lsm6dso
//
//  Parameters:
//    *outputPointer -- Pass &variable (base address of) to save read data to
//    offset -- register to read
//
//****************************************************************************//
lsm6dso_status_t read_register_int16_lsm6dso(int16_t* outputPointer, uint8_t offset) {
    uint8_t myBuffer[2];
    lsm6dso_status_t returnError = read_register_region_lsm6dso(myBuffer, offset, 2);  //Does memory transfer
    int16_t output = (int16_t)myBuffer[0] | (int16_t)(myBuffer[1] << 8);
    *outputPointer = output;
    return returnError;
}

//****************************************************************************//
//
//  write_register_lsm6dso
//
//  Parameters:
//    offset -- register to write
//    dataToWrite -- 8 bit data to write to register
//
//****************************************************************************//
lsm6dso_status_t write_register_lsm6dso(uint8_t offset, uint8_t dataToWrite) {
    lsm6dso_status_t returnError = IMU_SUCCESS;
    // ------------- SPI Process --------------
    uint8_t tx_buf[2] = { offset, dataToWrite };
    nrfx_spi_xfer_desc_t spi_xfer_desc = NRFX_SPI_XFER_TX(tx_buf, 2);
    nrfx_err_t status = nrfx_spi_xfer(&m_spi_lsm6dso, &spi_xfer_desc, 0);
    //NRFX_ASSERT(status == NRFX_SUCCESS);
    return returnError;
}

lsm6dso_status_t embedded_page_lsm6dso(void) {
    lsm6dso_status_t returnError = write_register_lsm6dso(LSM6DSO_RAM_ACCESS, 0x80);
    return returnError;
}

lsm6dso_status_t base_page_lsm6dso(void) {
    lsm6dso_status_t returnError = write_register_lsm6dso(LSM6DSO_RAM_ACCESS, 0x00);
    return returnError;
}

//****************************************************************************//
//
//  Accelerometer section
//
//****************************************************************************//
int16_t read_raw_accel_x_lsm6dso(void) {
    int16_t output;
    lsm6dso_status_t errorLevel = read_register_int16_lsm6dso(&output, LSM6DSO_OUTX_L_XL);
    return output;
}

float read_float_accel_x_lsm6dso(void) {
    float output = calc_accel_lsm6dso(read_raw_accel_x_lsm6dso());
    return output;
}

int16_t read_raw_accel_y_lsm6dso(void) {
    int16_t output;
    lsm6dso_status_t errorLevel = read_register_int16_lsm6dso(&output, LSM6DSO_OUTY_L_XL);
    return output;
}

float read_float_accel_y_lsm6dso(void) {
    float output = calc_accel_lsm6dso(read_raw_accel_y_lsm6dso());
    return output;
}

int16_t read_raw_accel_z_lsm6dso(void) {
    int16_t output;
    lsm6dso_status_t errorLevel = read_register_int16_lsm6dso(&output, LSM6DSO_OUTZ_L_XL);
    return output;
}

float read_float_accel_z_lsm6dso(void) {
    float output = calc_accel_lsm6dso(read_raw_accel_z_lsm6dso());
    return output;
}

float calc_accel_lsm6dso(int16_t input) {
    float output = (float)input * 0.061 * (settings.accelRange >> 1) / 1000;
    return output;
}

//****************************************************************************//
//
//  Gyroscope section
//
//****************************************************************************//
int16_t read_raw_gyro_x_lsm6dso(void) {
    int16_t output;
    lsm6dso_status_t errorLevel = read_register_int16_lsm6dso(&output, LSM6DSO_OUTX_L_G);
    return output;
}

float read_float_gyro_x_lsm6dso(void) {
    float output = calc_gyro_lsm6dso(read_raw_gyro_x_lsm6dso());
    return output;
}

int16_t read_raw_gyro_y_lsm6dso(void) {
    int16_t output;
    lsm6dso_status_t errorLevel = read_register_int16_lsm6dso(&output, LSM6DSO_OUTY_L_G);
    return output;
}

float read_float_gyro_y_lsm6dso(void) {
    float output = calc_gyro_lsm6dso(read_raw_gyro_y_lsm6dso());
    return output;
}

int16_t read_raw_gyro_z_lsm6dso(void) {
    int16_t output;
    lsm6dso_status_t errorLevel = read_register_int16_lsm6dso(&output, LSM6DSO_OUTZ_L_G);
    return output;
}
float read_float_gyro_z_lsm6dso(void) {
    float output = calc_gyro_lsm6dso(read_raw_gyro_z_lsm6dso());
    return output;
}

float calc_gyro_lsm6dso(int16_t input) {
    uint8_t gyroRangeDivisor = settings.gyroRange / 125;
    if (settings.gyroRange == 245) {
        gyroRangeDivisor = 2;
    }
    float output = (float)input * 4.375 * (gyroRangeDivisor) / 1000;
    return output;
}

//****************************************************************************//
//
//  Temperature section
//
//****************************************************************************//
int16_t read_raw_temp_lsm6dso(void) {
    int16_t output;
    read_register_int16_lsm6dso(&output, LSM6DSO_OUT_TEMP_L);
    return output;
}

float read_temp_C_lsm6dso(void) {
    float output = (float)read_raw_temp_lsm6dso() / settings.tempSensitivity; //divide by tempSensitivity to scale
    output += 25; //Add 25 degrees to remove offset
    return output;
}

float read_temp_F_lsm6dso(void) {
    float output = (float)readRawTemp() / settings.tempSensitivity; //divide by tempSensitivity to scale
    output += 25; //Add 25 degrees to remove offset
    output = (output * 9) / 5 + 32;
    return output;
}

//****************************************************************************//
//
//  FIFO section
//
//****************************************************************************//
void fifo_begin_lsm6dso(void) {
    //CONFIGURE THE VARIOUS FIFO SETTINGS
    //
    //
    //This section first builds a bunch of config words, then goes through
    //and writes them all.

    //Split and mask the threshold
    uint8_t thresholdLByte = settings.fifoThreshold & 0x00FF;
    uint8_t thresholdHByte = (settings.fifoThreshold & 0x0F00) >> 8;
    //Pedo bits not configured (ctl2)

    //CONFIGURE FIFO_CTRL3
    uint8_t tempFIFO_CTRL3 = 0;
    if (settings.gyroFifoEnabled == 1) {
        //Set up gyro stuff
        //Build on FIFO_CTRL3
        //Set decimation
        tempFIFO_CTRL3 |= (settings.gyroFifoDecimation & 0x07) << 3;

    }
    if (settings.accelFifoEnabled == 1) {
        //Set up accelerometer stuff
        //Build on FIFO_CTRL3
        //Set decimation
        tempFIFO_CTRL3 |= (settings.accelFifoDecimation & 0x07);
    }

    //CONFIGURE FIFO_CTRL4  (nothing for now-- sets data sets 3 and 4
    uint8_t tempFIFO_CTRL4 = 0;


    //CONFIGURE FIFO_CTRL5
    uint8_t tempFIFO_CTRL5 = 0;
    switch (settings.fifoSampleRate) {
        default:  //set default case to 10Hz(slowest)
        case 10:
            tempFIFO_CTRL5 |= LSM6DSO_ODR_FIFO_10Hz;
            break;
        case 25:
            tempFIFO_CTRL5 |= LSM6DSO_ODR_FIFO_25Hz;
            break;
        case 50:
            tempFIFO_CTRL5 |= LSM6DSO_ODR_FIFO_50Hz;
            break;
        case 100:
            tempFIFO_CTRL5 |= LSM6DSO_ODR_FIFO_100Hz;
            break;
        case 200:
            tempFIFO_CTRL5 |= LSM6DSO_ODR_FIFO_200Hz;
            break;
        case 400:
            tempFIFO_CTRL5 |= LSM6DSO_ODR_FIFO_400Hz;
            break;
        case 800:
            tempFIFO_CTRL5 |= LSM6DSO_ODR_FIFO_800Hz;
            break;
        case 1600:
            tempFIFO_CTRL5 |= LSM6DSO_ODR_FIFO_1600Hz;
            break;
        case 3300:
            tempFIFO_CTRL5 |= LSM6DSO_ODR_FIFO_3300Hz;
            break;
        case 6600:
            tempFIFO_CTRL5 |= LSM6DSO_ODR_FIFO_6600Hz;
            break;
    }
    //Hard code the fifo mode here:
    tempFIFO_CTRL5 |= settings.fifoModeWord = 6;  //set mode:

    //Write the data
    write_register_lsm6dso(LSM6DSO_FIFO_CTRL1, thresholdLByte);
    //Serial.println(thresholdLByte, HEX);
    write_register_lsm6dso(LSM6DSO_FIFO_CTRL2, thresholdHByte);
    //Serial.println(thresholdHByte, HEX);
    write_register_lsm6dso(LSM6DSO_FIFO_CTRL3, tempFIFO_CTRL3);
    write_register_lsm6dso(LSM6DSO_FIFO_CTRL4, tempFIFO_CTRL4);
    write_register_lsm6dso(LSM6DSO_FIFO_CTRL5, tempFIFO_CTRL5);

}
void fifo_clear_lsm6dso(void) {
    //Drain the fifo data and dump it
    while ((fifoGetStatus() & 0x1000) == 0) {
        fifoRead();
    }

}
int16_t fifo_read_lsm6dso(void) {
    //Pull the last data from the fifo
    uint8_t tempReadByte = 0;
    uint16_t tempAccumulator = 0;
    read_register_lsm6dso(&tempReadByte, LSM6DSO_FIFO_DATA_OUT_L);
    tempAccumulator = tempReadByte;
    read_register_lsm6dso(&tempReadByte, LSM6DSO_FIFO_DATA_OUT_H);
    tempAccumulator |= ((uint16_t)tempReadByte << 8);

    return tempAccumulator;
}

uint16_t fifo_get_status_lsm6dso(void) {
    //Return some data on the state of the fifo
    uint8_t tempReadByte = 0;
    uint16_t tempAccumulator = 0;
    read_register_lsm6dso(&tempReadByte, LSM6DSO_FIFO_STATUS1);
    tempAccumulator = tempReadByte;
    read_register_lsm6dso(&tempReadByte, LSM6DSO_FIFO_STATUS2);
    tempAccumulator |= (tempReadByte << 8);

    return tempAccumulator;

}
void fifo_end_lsm6dso(void) {
    // turn off the fifo
    write_register_lsm6dso(LSM6DSO_FIFO_STATUS1, 0x00);  //Disable
}




