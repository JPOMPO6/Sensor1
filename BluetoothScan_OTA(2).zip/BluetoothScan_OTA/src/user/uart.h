#ifndef UART_H
#define UART_H

#include <nrf.h>
#include <nrfx_uart.h>

#define UART_INSTANCE NRF_UART0

#ifdef	__cplusplus
extern "C" {
#endif
    
    void uart_init(void);
    void uart_putchar(uint8_t ch);
    uint8_t uart_getchar(void);
    void uart_puts(uint8_t * str);
    void uart_gets(uint8_t * buf,int len);
    void decimal_to_char( int32_t decimal );

#ifdef	__cplusplus
}
#endif

#endif /* UART_H */