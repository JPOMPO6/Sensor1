#ifndef NRF_DELAY_H
#define NRF_DELAY_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#include <stdint.h>
/**
 * @brief Function for delaying execution for the specified number of microseconds.
 *
 * @param number_of_us  Number of microseconds to delay execution for.
 */
void nrf_delay_us(uint32_t number_of_us);

/**
 * @brief Function for delaying execution for the specified number of milliseconds.
 *
 * @param number_of_ms  Number of milliseconds to delay execution for.
 */
void nrf_delay_ms(uint32_t number_of_ms);

#ifdef	__cplusplus
}
#endif

#endif /* NRF_DELAY_H */