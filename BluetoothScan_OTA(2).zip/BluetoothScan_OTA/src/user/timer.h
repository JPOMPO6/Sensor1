#ifndef TIMER_H
#define TIMER_H

#include <nrf.h>
#include <nrfx.h>
#include <nrfx_timer.h>

#define TIMER0_INSTANCE NRF_TIMER0
#define TIMER1_INSTANCE NRF_TIMER1
#define TIMER_INTERVAL_MS   1000

#ifdef	__cplusplus
extern "C" {
#endif
    static const nrfx_timer_t m_timer = NRFX_TIMER_INSTANCE(0);
    void timer0_init(void);
    void timer1_init(void);
    void timer_init(void);
    void timer_handler(nrf_timer_event_t event_type, void* p_context);
    void timer0_start();
    void timer0_stop();
    void timer1_start();
    void timer1_stop();
    void timer_start(nrfx_timer_t const * p_instance);
    void timer_stop(nrfx_timer_t const * p_instance);

#ifdef	__cplusplus
}
#endif

#endif /* TIMER_H */