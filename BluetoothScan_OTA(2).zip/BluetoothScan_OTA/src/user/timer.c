#include "timer.h"
#include "uart.h"

void timer_init(void) {
	// Initialize the timer
    nrfx_timer_config_t timer_cfg = NRFX_TIMER_DEFAULT_CONFIG;
    timer_cfg.p_context = "Some context";
    nrfx_err_t status = nrfx_timer_init(&m_timer, &timer_cfg, timer_handler);
    
    // Configure the timer with desired settings
    uint32_t timer_ticks = nrfx_timer_ms_to_ticks(&m_timer, TIMER_INTERVAL_MS);
    nrfx_timer_extended_compare(&m_timer, NRF_TIMER_CC_CHANNEL0, NRF_TIMER_SHORT_COMPARE0_CLEAR_MASK, timer_ticks, true);
    
    // Enable and start the timer
    nrfx_timer_enable(&m_timer);
    nrfx_timer_resume(&m_timer);
}

void timer0_init(void){
	TIMER0_INSTANCE->MODE = TIMER_MODE_MODE_Timer;  // Set the timer in Counter Mode
  	TIMER0_INSTANCE->TASKS_CLEAR = 1;               // clear the task first to be usable for later
	TIMER0_INSTANCE->PRESCALER = 6;                             //Set prescaler. Higher number gives slower timer. Prescaler = 0 gives 16MHz timer
	TIMER0_INSTANCE->BITMODE = TIMER_BITMODE_BITMODE_16Bit;		 //Set counter to 16 bit resolution
	TIMER0_INSTANCE->CC[0] = 16000;                             //Set value for TIMER0 compare register 0
		
  	// Enable interrupt on Timer 2, both for CC[0] and CC[1] compare match events
	TIMER0_INSTANCE->INTENSET = (TIMER_INTENSET_COMPARE0_Enabled << TIMER_INTENSET_COMPARE0_Pos);
  	NVIC_EnableIRQ(TIMER0_IRQn);
  	TIMER0_INSTANCE->TASKS_START = 1;               // Start TIMER0
}

void timer1_init(void){

	TIMER1_INSTANCE->TASKS_STOP = 1;                // Stop timer
	TIMER1_INSTANCE->MODE = TIMER_MODE_MODE_Timer;  // Set the timer in Counter Mode
	TIMER1_INSTANCE->BITMODE = TIMER_BITMODE_BITMODE_16Bit;		 //Set counter to 16 bit resolution
	TIMER1_INSTANCE->PRESCALER = 8;                             //Set prescaler. Higher number gives slower timer. Prescaler = 0 gives 16MHz timer
  	TIMER1_INSTANCE->TASKS_CLEAR = 1;               // clear the task first to be usable for later
	TIMER1_INSTANCE->CC[0] = 16000;                             //Set value for TIMER1 compare register 0
	// TIMER1_INSTANCE->CC[1] = 20000;                             //Set value for TIMER1 compare register 1		
  	// Enable interrupt on Timer 2, both for CC[0] and CC[1] compare match events
	TIMER1_INSTANCE->INTENSET = (TIMER_INTENSET_COMPARE0_Enabled << TIMER_INTENSET_COMPARE0_Pos);
	TIMER1_INSTANCE->SHORTS = (TIMER_SHORTS_COMPARE0_CLEAR_Enabled << TIMER_SHORTS_COMPARE0_CLEAR_Pos);
  	NVIC_EnableIRQ(TIMER1_IRQn);
  	TIMER1_INSTANCE->TASKS_START = 1;               // Start TIMER1
}

void timer_handler(nrf_timer_event_t event_type, void* p_context){
	switch (event_type)
	{
		case NRF_TIMER_EVENT_COMPARE0: 
			char * p_msg = p_context;
			uart_puts("\r\nTimer finished. Context passed to the handler"); uart_puts(p_msg); break;
	
		default:
			break;
	}
}

void timer_start(nrfx_timer_t const * p_instance){
	nrfx_timer_resume(&p_instance);
	uart_puts("\r\nTimer started");
}

void timer_stop(nrfx_timer_t const * p_instance){
	nrfx_timer_pause(&p_instance);
	uart_puts("\r\nTimer stoped");
}

void timer0_start(){
	TIMER0_INSTANCE->TASKS_START = 1; 
	TIMER0_INSTANCE->TASKS_STOP =  0; 
}

void timer0_stop(){
	TIMER0_INSTANCE->TASKS_START = 0;
	TIMER0_INSTANCE->TASKS_STOP =  1; 
}

void timer1_start(){
	TIMER1_INSTANCE->TASKS_START = 1; 
	TIMER1_INSTANCE->TASKS_STOP =  0; 
}

void timer1_stop(){
	TIMER1_INSTANCE->TASKS_START = 0; 
	TIMER1_INSTANCE->TASKS_STOP =  1; 
}